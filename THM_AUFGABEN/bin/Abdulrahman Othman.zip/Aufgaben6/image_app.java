package Aufgaben6;
public class image_app {
    public static void main(String[] args) {
        image i = new image();

        i.setXiny("cross");
        i.getXiny();
    }
}
