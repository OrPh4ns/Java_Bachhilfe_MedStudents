package Aufgaben1;
public class Fehlersuche {

    public static void main(String args) {

        boolean m =  true;
        short a = 29356;
        int b = 0x18;
        double c = 89.91;
        int d = 1274;
        String e = "B00011000";
        int f = 030;
        char g = 'a';
        String h = "hallo";
        int i = 26;
        long j = 9356825811l;
        float k = 299999.2f;
        int l;

        System.out.println(a + i); System.out.println(a);

    }
}