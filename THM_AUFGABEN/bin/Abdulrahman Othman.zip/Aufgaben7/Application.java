package Aufgaben7;
import java.io.IOException;

public class Application {

    public static void main(String[] args) throws IOException, TodException {
    	Patient p1 = new Patient("Ali", 0);
    	p1.setPuls();
    }
}
