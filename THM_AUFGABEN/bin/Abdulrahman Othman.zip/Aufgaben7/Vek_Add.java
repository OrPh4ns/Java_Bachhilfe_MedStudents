package Aufgaben7;
public class Vek_Add {
    int x;
    int y;
    public Vek_Add(int x , int y){
        this.x = x;
        this.y = y;
    }

    public int getX(){
        return x;
    }
    public int getY(){
        return y;
    }
}
