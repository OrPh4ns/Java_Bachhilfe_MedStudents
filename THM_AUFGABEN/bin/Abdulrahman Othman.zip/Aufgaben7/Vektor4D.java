package Aufgaben7;
public class Vektor4D {
    
}
